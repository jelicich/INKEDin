<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana_HTTP_Exception_400 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 400 Bad Request
	 */
	protected $_code = 400;

}
