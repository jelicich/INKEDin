<?php defined('SYSPATH') OR die('No direct script access.');

class Log extends Kohana_Log {}
