<?php defined('SYSPATH') OR die('No direct script access.');

class Log_StdOut extends Kohana_Log_StdOut {}
