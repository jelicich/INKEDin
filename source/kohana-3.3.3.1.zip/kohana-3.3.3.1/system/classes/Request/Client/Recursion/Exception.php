<?php defined('SYSPATH') OR die('No direct script access.');

class Request_Client_Recursion_Exception extends Kohana_Request_Client_Recursion_Exception {}
