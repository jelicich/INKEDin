<?php defined('SYSPATH') OR die('No direct script access.');

class View_Exception extends Kohana_View_Exception {}
