<?php
// See the Kohana_CoreTest tests for Kohana::message
return array(
	'bottom_only'   => 'inherited bottom message',
	'cfs_replaced'  => 'inherited cfs_replaced message',
);
